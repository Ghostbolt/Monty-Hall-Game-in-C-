﻿//Name          :   Leroy Jiyane    
//Student Number:   2019142336
//Date          :   06/06/2020
//Exercise      :   Assignment 1 
//Type of App   :   Console App 
//Module        :   CSIS1614
using System;


namespace _2019142336_Assignment1
{
    class Program
    {
        static void Main()
        {
            Random rand = new Random(DateTime.Now.Millisecond);
            char cUserChoice, cUserChoice2;
            int iWinDoor = rand.Next(65, 67);
            Console.WriteLine("You are a contestant in a game show.");
            Console.WriteLine("On the stage, there are three doors");
            Console.WriteLine("Behind one of the doors is a prize, behind the other two nothing.");
            Console.WriteLine("=================================================================");

            Console.Write("\nChoose a door (A,B or C):");
            cUserChoice = Console.ReadKey().KeyChar.ToString().ToUpper()[0];
            Console.Write("\n");

            if (string.Compare(cUserChoice.ToString(), "A") == 0 || string.Compare(cUserChoice.ToString(), "B") == 0 || string.Compare(cUserChoice.ToString(), "C") == 0)
            {
               // Console.WriteLine("\nYour first choice is : {0}", cUserChoice.ToString());
               // Console.WriteLine();

            }
            else
            {
                Console.WriteLine("\nInvalid choice");
                Main();
            }
            Console.WriteLine();


            if (string.Compare(cUserChoice.ToString(), "A") == 0 && string.Compare(Convert.ToChar(66).ToString(), Convert.ToChar(iWinDoor).ToString(), true) != 0)
            {
                Console.WriteLine("I can confirm that the prize is not behind the door {0}.", Convert.ToChar(66).ToString().ToUpper()[0]);
                Console.WriteLine("In fact, let me open it for you. See, no prize there.");
                Console.WriteLine();
                Console.WriteLine("Would you like to stick with your orginal choice,{0}, or would like to change to {1}?", Convert.ToChar(65).ToString().ToUpper()[0], Convert.ToChar(67).ToString().ToUpper()[0]);
                Console.Write("Please enter the letter corresponding to your choice:");

                cUserChoice2 = Console.ReadKey().KeyChar.ToString().ToUpper()[0];
                Console.WriteLine();

                if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(66).ToString(), true) == 0)
                {
                    Console.WriteLine();
                   
                    Console.WriteLine("Invalid Choice. That door was opened by the host.");

                }

                else if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(66).ToString(), true) != 0)
                {
                    if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(iWinDoor).ToString()) == 0)
                    {
                        Console.WriteLine();
                       
                        Console.WriteLine("Congratulations, you won!");
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("Your choice:{0}", cUserChoice2.ToString());
                        Console.WriteLine("Wrong choice you lost the correct door was {0}", Convert.ToChar(iWinDoor).ToString().ToUpper()[0]);
                    }
                }

            }
            else if (string.Compare(cUserChoice.ToString(), "A") == 0 && string.Compare(Convert.ToChar(67).ToString(), Convert.ToChar(iWinDoor).ToString(), true) != 0)
            {
                Console.WriteLine("I can confirm that the prize is not behind the door {0}.", Convert.ToChar(67).ToString().ToUpper()[0]);
                Console.WriteLine("In fact, let me open it for you. See, no prize there.");
                Console.WriteLine();
                Console.WriteLine("Would you like to stick with your orginal choice,{0}, or would like to change to {1}?", Convert.ToChar(65).ToString().ToUpper()[0], Convert.ToChar(66).ToString().ToUpper()[0]);
                Console.Write("Please enter the letter corresponding to your choice:");

                cUserChoice2 = Console.ReadKey().KeyChar.ToString().ToUpper()[0];
                Console.WriteLine();
                if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(67).ToString(), true) == 0)
                {
                    Console.WriteLine();

                   
                    Console.WriteLine("Invalid choice. That door was opened by the host.");
                }

                else if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(67).ToString(), true) != 0)
                {
                    if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(iWinDoor).ToString()) == 0)
                    {
                        Console.WriteLine();

                       
                        Console.WriteLine("Congratulations, you won!");
                    }
                    else
                    {
                        Console.WriteLine();

                       
                        Console.WriteLine("Wrong choice you lost the correct door was {0}.", Convert.ToChar(iWinDoor).ToString().ToUpper()[0]);
                    }
                }
            }
            else if (string.Compare(cUserChoice.ToString(), "B") == 0 && string.Compare(Convert.ToChar(65).ToString(), Convert.ToChar(iWinDoor).ToString(), true) != 0)
            {
                Console.WriteLine("I can confirm that the prize is not behind the door {0}.", Convert.ToChar(65).ToString().ToUpper()[0]);
                Console.WriteLine("In fact, let me open it for you. See, no prize there.");
                Console.WriteLine();

                Console.WriteLine("Would you like stick with your original choice, {0}, or would like to change to {1}?", Convert.ToChar(66).ToString().ToUpper()[0], Convert.ToChar(67).ToString().ToUpper()[0]);
                Console.Write("Please enter the letter corresponding to your choice: ");
                cUserChoice2 = Console.ReadKey().KeyChar.ToString().ToUpper()[0];
                Console.WriteLine();

                if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(65).ToString(), true) == 0)
                {
                    Console.WriteLine();

                   
                    Console.WriteLine("Invalid choice. That door was opened by the host.");
                }

                else if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(65).ToString(), true) != 0)
                {
                    if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(iWinDoor).ToString()) == 0)
                    {
                        Console.WriteLine();

                       
                        Console.WriteLine("Congratulations, you won!");
                    }
                    else
                    {
                        Console.WriteLine();

                       
                        Console.WriteLine("Wrong choice you lost the correct door was {0}.", Convert.ToChar(iWinDoor).ToString().ToUpper()[0]);
                    }
                }
            }
            else if (string.Compare(cUserChoice.ToString(), "B") == 0 && string.Compare(Convert.ToChar(67).ToString(), Convert.ToChar(iWinDoor).ToString(), true) != 0)
            {
                Console.WriteLine("I can confirm that the prize is not behind the door {0}.", Convert.ToChar(67).ToString().ToUpper()[0]);
                Console.WriteLine("In fact, let me open it for you. See, no prize there.");
                Console.WriteLine();

                Console.WriteLine("Would you like stick with your original choice, {0}, or would like to change to {1}?", Convert.ToChar(66).ToString().ToUpper()[0], Convert.ToChar(65).ToString().ToUpper()[0]);
                Console.Write("Please enter the letter corresponding to your choice: ");
                cUserChoice2 = Console.ReadKey().KeyChar.ToString().ToUpper()[0];
                Console.WriteLine();

                if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(67).ToString(), true) == 0)
                {
                    Console.WriteLine();

                   
                    Console.WriteLine("Invalid choice. That door was opened by the host.");
                }
                else
                    if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(67).ToString(), true) != 0)
                {
                    if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(iWinDoor).ToString()) == 0)
                    {
                        Console.WriteLine();
                       
                        Console.WriteLine("Congratulations, you won!");
                    }
                    else
                    {
                        Console.WriteLine();
                       
                        Console.WriteLine("Wrong choice you lost the correct door was {0}.", Convert.ToChar(iWinDoor).ToString().ToUpper()[0]);
                    }
                }
            }
            else if (string.Compare(cUserChoice.ToString(), "C") == 0 && string.Compare(Convert.ToChar(65).ToString(), Convert.ToChar(iWinDoor).ToString(), true) != 0)
            {
                Console.WriteLine("I can confirm that the prize is not behind the door {0}.", Convert.ToChar(65).ToString().ToUpper()[0]);
                Console.WriteLine("In fact, let me open it for you. See, no prize there.");
                Console.WriteLine();

                Console.WriteLine("Would you like stick with your original choice, {0}, or would like to change to {1}?", Convert.ToChar(67).ToString().ToUpper()[0], Convert.ToChar(66).ToString().ToUpper()[0]);
                Console.Write("Please enter the letter corresponding to your choice: ");

                cUserChoice2 = Console.ReadKey().KeyChar.ToString().ToUpper()[0];
                Console.WriteLine();

                if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(65).ToString(), true) == 0)
                {
                    Console.WriteLine();
                   
                    Console.WriteLine("Invalid choice. That door was opened by the host.");
                }

                else if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(65).ToString(), true) != 0)
                {
                    if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(iWinDoor).ToString()) == 0)
                    {
                        Console.WriteLine();
                       
                        Console.WriteLine("Congratulations, you won!");
                    }
                    else
                    {
                        Console.WriteLine();
                       
                        Console.WriteLine("Wrong choice you lost the correct door was {0}.", Convert.ToChar(iWinDoor).ToString().ToUpper()[0]);
                    }
                }
            }
            else if (string.Compare(cUserChoice.ToString(), "C") == 0 && string.Compare(Convert.ToChar(66).ToString(), Convert.ToChar(iWinDoor).ToString(), true) != 0)
            {
                Console.WriteLine("I can confirm that the prize is not behind the door {0}.", Convert.ToChar(66).ToString().ToUpper()[0]);
                Console.WriteLine("In fact, let me open it for you. See, no prize there.");
                Console.WriteLine();

                Console.WriteLine("Would you like stick with your original choice, {0}, or would like to change to {1}?", Convert.ToChar(67).ToString().ToUpper()[0], Convert.ToChar(65).ToString().ToUpper()[0]);
                Console.Write("Please enter the letter corresponding to your choice: ");

                cUserChoice2 = Console.ReadKey().KeyChar.ToString().ToUpper()[0];
                Console.WriteLine();

                if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(66).ToString(), true) == 0)
                {
                    Console.WriteLine();
                   
                    Console.WriteLine("Invalid choice. That door was opened by the host.");
                }

                else if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(66).ToString(), true) != 0)
                {
                    if (string.Compare(cUserChoice2.ToString(), Convert.ToChar(iWinDoor).ToString()) == 0)
                    {
                        Console.WriteLine();
                       
                        Console.WriteLine("Congratulations, you won!");
                    }
                    else
                    {
                        Console.WriteLine();
                       
                        Console.WriteLine("Wrong choice you lost, the correct door was {0}.", Convert.ToChar(iWinDoor).ToString().ToUpper()[0]);

                    }
                }
            }
            
            Console.Write("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
